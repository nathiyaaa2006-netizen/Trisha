<?php
include 'dbconn.php';

$sql = "SELECT s_no, user_id, date, content, status, created_at FROM reports";
$result = mysqli_query($conn, $sql);

$reports = [];

if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $reports[] = $row;
    }
    echo json_encode($reports);
} else {
    echo json_encode(["error" => "Failed to fetch reports"]);
}

mysqli_close($conn);
?>
